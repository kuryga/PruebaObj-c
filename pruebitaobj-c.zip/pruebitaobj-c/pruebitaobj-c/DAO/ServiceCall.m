//
//  ServiceDAO.m
//  pruebitaobj-c
//
//  Created by Abelardo Gonzalez on 28/10/2019.
//  Copyright © 2019 Abelardo Gonzalez. All rights reserved.
//

#import "ServiceCall.h"

@implementation ServiceCall
@synthesize albumDelegate, albumDetailDelegate;

- (void) getAlbums {
    [[[NSURLSession sharedSession] dataTaskWithURL: [NSURL URLWithString:@"https://jsonplaceholder.typicode.com/todos"] completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        if (error != nil) {
            
            NSDictionary *errorDict = error.userInfo;
            [self->albumDelegate failure:errorDict];
        } else {
            NSMutableArray *array = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
            NSMutableArray *tbValueArray = [[NSMutableArray alloc] init];
            
            for (int i = 0; i < [array count]; i++) {
                [tbValueArray addObject:[array objectAtIndex:i]];
            }
            
            [self->albumDelegate success:tbValueArray];
        }
        
    }]resume];
}

- (void) getAlbumDetail:(NSNumber *)idNumber {
    [[[NSURLSession sharedSession] dataTaskWithURL: [NSURL URLWithString:[NSString stringWithFormat: @"https://jsonplaceholder.typicode.com/photos/%@", idNumber]] completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        if (error != nil) {
            
            NSDictionary *errorDict = error.userInfo;
            [self->albumDetailDelegate failure:errorDict];
        } else {
            NSMutableDictionary *tbValuedict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
             NSMutableArray *array = [[NSMutableArray alloc] init];
            [array addObject:tbValuedict];
            [self->albumDetailDelegate success:array];
        }
        
    }]resume];
}


@end
