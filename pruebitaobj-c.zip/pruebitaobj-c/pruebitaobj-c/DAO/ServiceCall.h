//
//  ServiceDAO.h
//  pruebitaobj-c
//
//  Created by Abelardo Gonzalez on 28/10/2019.
//  Copyright © 2019 Abelardo Gonzalez. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ServiceCall;           

@protocol ServiceCallDelegate <NSObject>
@required
- (void) success: (NSMutableArray *)dict;
- (void) failure: (NSDictionary *)error;
@end //end protocol

@protocol ServiceDetailCallDelegate <NSObject>
@required
- (void) success: (NSMutableArray *)dict;
- (void) failure: (NSDictionary *)error;
@end 

@interface ServiceCall : NSObject

@property (nonatomic, weak) id <ServiceCallDelegate> albumDelegate;
@property (nonatomic, weak) id <ServiceDetailCallDelegate> albumDetailDelegate;

- (void) getAlbums;
- (void) getAlbumDetail:(NSNumber *)idNumber;

@end
