//
//  AlbumDetailViewController.m
//  pruebitaobj-c
//
//  Created by Abelardo Gonzalez on 30/10/2019.
//  Copyright © 2019 Abelardo Gonzalez. All rights reserved.
//

#import "AlbumDetailViewController.h"
#import "AlbumDetailTableViewCell.h"
#import "ServiceCall.h"

@interface AlbumDetailViewController ()

@property (weak, nonatomic) IBOutlet UITableView *detailTableView;

@property(strong, nonatomic)NSMutableArray *albumsDetailsArray;
@property (nonatomic, weak) id<ServiceDetailCallDelegate> delegate;

@end

@implementation AlbumDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.detailTableView.delegate = self;
    self.detailTableView.dataSource = self;
    
    [self.detailTableView registerNib:[UINib nibWithNibName:@"AlbumDetailTableViewCell" bundle:nil]
         forCellReuseIdentifier:@"AlbumDetailCell"];
    [self calltoservice];
}

-(void) calltoservice {
    ServiceCall *service = [[ServiceCall alloc] init];
    service.albumDetailDelegate = self;
    [service getAlbumDetail:self.idQuery];
}

- (NSInteger)tableView:(nonnull UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.albumsDetailsArray.count;
}

- (UITableViewCell *)tableView:(nonnull UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    AlbumDetailTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"AlbumDetailCell"];
    if (cell == nil) {
        cell = [[AlbumDetailTableViewCell alloc]init];
    }
    cell.titleLabel.text = [[NSString alloc] initWithString:[[self.albumsDetailsArray objectAtIndex:indexPath.row] valueForKey:@"title"]];
    cell.idLabel.text = [NSString stringWithFormat: @"ID: %@", [[[self.albumsDetailsArray objectAtIndex:indexPath.row] valueForKey:@"id"] stringValue]];
    NSString *urlString = [[NSString alloc] initWithString:[[self.albumsDetailsArray objectAtIndex:indexPath.row] valueForKey:@"url"]];
    [self loadImageFromURL:urlString webView:cell.albumImageView];
    
    return cell;
}

- (void)failure:(NSDictionary *)error {
     [self raiseAlertForNoConnection:error];
}

- (void)success:(NSMutableArray *)dict {
    self.albumsDetailsArray = dict;
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.detailTableView reloadData];
    });
}

- (void)raiseAlertForNoConnection:(NSDictionary *)error {
    
    NSString *errormessage = [error valueForKey:@"NSLocalizedDescription"];
    UIAlertController * alert = [UIAlertController alertControllerWithTitle:@"Atention" message:errormessage preferredStyle:UIAlertControllerStyleAlert];
    
    
    UIAlertAction* retryButton = [UIAlertAction actionWithTitle:@"Retry" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
        [self calltoservice];
    }];
    
    UIAlertAction* cancelButton = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction * action) {
    }];
    
    [alert addAction:retryButton];
    [alert addAction:cancelButton];
    [self presentViewController:alert animated:true completion:nil];
}

-(void)loadImageFromURL:(NSString *)urlString webView:(UIImageView *)cellImageView {
    NSString *imgString = urlString;
    NSData *imageData = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:imgString]];
    
    cellImageView.image = [UIImage imageWithData: imageData]; // accountImageView is imageView

}



@end
