//
//  AlbumDetailViewController.h
//  pruebitaobj-c
//
//  Created by Abelardo Gonzalez on 30/10/2019.
//  Copyright © 2019 Abelardo Gonzalez. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ServiceCall.h"

@interface AlbumDetailViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, ServiceDetailCallDelegate>

@property (strong, nonatomic) NSNumber *idQuery;
@end


