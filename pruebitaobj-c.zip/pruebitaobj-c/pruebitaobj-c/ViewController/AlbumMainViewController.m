//
//  ViewController.m
//  pruebitaobj-c
//
//  Created by Abelardo Gonzalez on 28/10/2019.
//  Copyright © 2019 Abelardo Gonzalez. All rights reserved.
//

#import "AlbumMainViewController.h"
#import "ServiceCall.h"
#import "AlbumCustomCell.h"
#import "AlbumDetailViewController.h"

@interface AlbumMainViewController()

@property (weak, nonatomic) IBOutlet UISearchBar *albumSearchBar;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(strong, nonatomic)NSMutableArray *albumsArray;
@property (nonatomic, weak) id<ServiceCallDelegate> delegate;

@property (strong, nonatomic) NSMutableArray *filteredTitles;
@property (assign, nonatomic) BOOL isFiltered;
@property (weak, nonatomic) NSNumber *idNumber;

@end

@implementation AlbumMainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    [self.tableView registerNib:[UINib nibWithNibName:@"AlbumCustomCell" bundle:nil]
         forCellReuseIdentifier:@"AlbumCell"];
    
    self.isFiltered = false;
    
    self.albumSearchBar.delegate = self;
    
    [self calltoservice];
}
-(void) calltoservice {
    ServiceCall *service = [[ServiceCall alloc] init];
    service.albumDelegate = self;
    [service getAlbums];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
{
    if (self.isFiltered) {
        return self.filteredTitles.count;
    }
    return self.albumsArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    AlbumCustomCell *cell = [tableView dequeueReusableCellWithIdentifier:@"AlbumCell"];
    if (cell == nil) {
        cell = [[AlbumCustomCell alloc]init];
    }
    if (!self.isFiltered) {
        cell.titleLabel.text = [[NSString alloc] initWithString:[[self.albumsArray objectAtIndex:indexPath.row] valueForKey:@"title"]];
        cell.idLabel.text = [NSString stringWithFormat: @"ID: %@", [[[self.albumsArray objectAtIndex:indexPath.row] valueForKey:@"id"] stringValue]];
    } else {
        cell.titleLabel.text = [[NSString alloc] initWithString:[[self.filteredTitles objectAtIndex:indexPath.row] valueForKey:@"title"]];
        cell.idLabel.text = [NSString stringWithFormat: @"ID: %@", [[[self.filteredTitles objectAtIndex:indexPath.row] valueForKey:@"id"] stringValue]];
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    self.idNumber = [[self.albumsArray objectAtIndex:indexPath.row] valueForKey:@"id"];
    
    [self performSegueWithIdentifier:@"goToAlbumDetail" sender:nil];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
    
    if (searchText.length == 0) {
        
        self.isFiltered = false;
        
    } else {
        self.isFiltered = true;
        self.filteredTitles = [[NSMutableArray alloc]init];
        for (int i = 0; i < [self.albumsArray count]; i++) {
            if ([[[[self.albumsArray objectAtIndex:i] objectForKey:@"title"] lowercaseString] rangeOfString:[searchText lowercaseString]].length>0) {
                [self.filteredTitles addObject:[self.albumsArray objectAtIndex:i]];
            }
        }
    }
    [self.tableView reloadData];
}

- (void)failure:(NSDictionary *)error {
    [self raiseAlertForNoConnection:error];
}

- (void)success:(NSMutableArray *)dict {
    self.albumsArray = dict;
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.tableView reloadData];
    });
}

- (void)raiseAlertForNoConnection:(NSDictionary *)error {
    
    NSString *errormessage = [error valueForKey:@"NSLocalizedDescription"];
    UIAlertController * alert = [UIAlertController alertControllerWithTitle:@"Atention" message:errormessage preferredStyle:UIAlertControllerStyleAlert];
    
    
    UIAlertAction* retryButton = [UIAlertAction actionWithTitle:@"Retry" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
        [self calltoservice];
    }];
    
    UIAlertAction* cancelButton = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction * action) {
    }];
    
    [alert addAction:retryButton];
    [alert addAction:cancelButton];
    [self presentViewController:alert animated:true completion:nil];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([[segue identifier] isEqualToString:@"goToAlbumDetail"]) {
        AlbumDetailViewController *vc = [segue destinationViewController];
        vc.idQuery = self.idNumber;
    }
}

@end
