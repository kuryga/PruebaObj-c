//
//  ViewController.h
//  pruebitaobj-c
//
//  Created by Abelardo Gonzalez on 28/10/2019.
//  Copyright © 2019 Abelardo Gonzalez. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ServiceCall.h"

@interface AlbumMainViewController : UIViewController<UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate, ServiceCallDelegate>

@end

