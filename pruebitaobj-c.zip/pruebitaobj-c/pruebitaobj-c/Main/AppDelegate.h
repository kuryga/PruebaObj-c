//
//  AppDelegate.h
//  pruebitaobj-c
//
//  Created by Abelardo Gonzalez on 28/10/2019.
//  Copyright © 2019 Abelardo Gonzalez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

