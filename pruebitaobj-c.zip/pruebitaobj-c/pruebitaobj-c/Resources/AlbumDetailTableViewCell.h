//
//  AlbumDetailTableViewCell.h
//  pruebitaobj-c
//
//  Created by Abelardo Gonzalez on 30/10/2019.
//  Copyright © 2019 Abelardo Gonzalez. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Webkit/Webkit.h>

@interface AlbumDetailTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *idLabel;
@property (weak, nonatomic) IBOutlet UIImageView *albumImageView;

@end

