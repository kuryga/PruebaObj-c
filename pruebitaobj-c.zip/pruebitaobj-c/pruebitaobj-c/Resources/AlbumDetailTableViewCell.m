//
//  AlbumDetailTableViewCell.m
//  pruebitaobj-c
//
//  Created by Abelardo Gonzalez on 30/10/2019.
//  Copyright © 2019 Abelardo Gonzalez. All rights reserved.
//

#import "AlbumDetailTableViewCell.h"

@implementation AlbumDetailTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
     [self setSelectionStyle:UITableViewCellSelectionStyleNone];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
