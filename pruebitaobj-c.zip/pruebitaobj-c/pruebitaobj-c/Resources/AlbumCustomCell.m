//
//  AlbumCustomCell.m
//  pruebitaobj-c
//
//  Created by Abelardo Gonzalez on 29/10/2019.
//  Copyright © 2019 Abelardo Gonzalez. All rights reserved.
//

#import "AlbumCustomCell.h"

@implementation AlbumCustomCell

- (void)awakeFromNib {
    [super awakeFromNib];
    [self setSelectionStyle:UITableViewCellSelectionStyleNone];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
