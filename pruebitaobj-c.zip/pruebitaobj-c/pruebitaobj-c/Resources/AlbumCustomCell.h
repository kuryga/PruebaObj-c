//
//  AlbumCustomCell.h
//  pruebitaobj-c
//
//  Created by Abelardo Gonzalez on 29/10/2019.
//  Copyright © 2019 Abelardo Gonzalez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlbumCustomCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *idLabel;

@end
